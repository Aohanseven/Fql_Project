from scrapy.cmdline import execute
execute(['scrapy', 'crawl', 'anjukeshop_data_spider'])




