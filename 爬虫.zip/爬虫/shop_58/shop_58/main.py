
from scrapy.cmdline import execute
execute(['scrapy', 'crawl', 'shop58_url_spider'])
