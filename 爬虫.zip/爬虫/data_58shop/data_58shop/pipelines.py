    # -*- coding: utf-8 -*-
import pymysql
# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html


class DBPiplines(object):
    def process_item(self, item, spider):
        con = pymysql.connect(host='192.168.0.252', user='web_user', passwd='first2018pl,', db='FBDdata2',charset='utf8', port=3306)

        cue=con.cursor()
        print("mysql connect succes")
        try:
            # cue.execute("UPDATE shop58_data_copy SET content='%s' WHERE id = '%s'" % (str(item['content']),item['id']))
            cue.execute("UPDATE shop58_data SET is_ok='%s',monthly_rent='%s',store_status='%s',shop_type='%s',acreage='%s',width='%s',address='%s',depth='%s',height='%s',floor='%s',business_industry='%s',payment_method='%s',lease_mode='%s',lat='%s',lng='%s',content='%s' WHERE id='%s'" %
                        (item['is_ok'],item['monthly_rent'],item['store_status'],item['shop_type'],item['acreage'],item['width'],item['address'],item['depth'],item['height'],item['floor'],item['business_industry'],item['payment_method'],item['lease_mode'],item['lat'],item['lng'],item['content'],item['id']))
            print("Update success")
        except Exception as e:
            print("Update error:",e)
            con.rollback()
        else:
            con.commit()
        con.close()
        return item